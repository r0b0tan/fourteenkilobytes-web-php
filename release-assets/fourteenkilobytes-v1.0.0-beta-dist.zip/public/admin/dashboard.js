/**
 * fourteenkilobytes Dashboard Module
 *
 * Handles the overview page with posts, pages, and archive lists.
 * Extracted from inline script for better maintainability.
 */

function resetDashboardOverlays() {
  const modalBackdrop = document.getElementById('modal-backdrop');
  const modal = document.getElementById('modal');
  const modalActions = document.getElementById('modal-actions');
  const modalMessage = document.getElementById('modal-message');

  if (modalBackdrop) {
    modalBackdrop.classList.add('hidden');
    modalBackdrop.setAttribute('aria-hidden', 'true');
  }

  if (modal) {
    modal.className = 'modal hidden';
  }

  if (modalActions) {
    modalActions.innerHTML = '';
  }

  if (modalMessage) {
    modalMessage.textContent = '';
  }
}

window.addEventListener('pageshow', () => {
  resetDashboardOverlays();
});

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    resetDashboardOverlays();
  }
});

// Wait for dependencies
async function waitForDependencies() {
  await i18nReady();
  // App is loaded synchronously via module, but wait just in case
  while (!window.App) {
    await new Promise(r => setTimeout(r, 10));
  }
}

// Initialize dashboard
export async function init() {
  await waitForDependencies();

  resetDashboardOverlays();

  const dashboardView = document.getElementById('dashboard-view');
  const logoutBtn = document.getElementById('logout-btn');
  const postsList = document.getElementById('posts-list');
  const pagesList = document.getElementById('pages-list');
  const archiveList = document.getElementById('archive-list');
  const postsPagination = document.getElementById('posts-pagination');
  const pagesPagination = document.getElementById('pages-pagination');
  const archivePagination = document.getElementById('archive-pagination');
  const pageSizeSelect = document.getElementById('page-size');
  const searchInput = document.getElementById('search-input');
  const dateFromInput = document.getElementById('date-from');
  const dateToInput = document.getElementById('date-to');
  const dateRangeTrigger = document.getElementById('date-range-trigger');
  const dateRangeDropdown = document.getElementById('date-range-dropdown');
  const dateRangeLabel = document.getElementById('date-range-label');
  const clearDatesBtn = document.getElementById('clear-dates');
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  const errorAlert = document.getElementById('error-alert');

  const modalBackdrop = document.getElementById('modal-backdrop');
  const modal = document.getElementById('modal');
  const modalActions = document.getElementById('modal-actions');
  const modalMessage = document.getElementById('modal-message');

  function clearStaleModalBackdrop() {
    if (!modal || !modalBackdrop) return;
    if (modal.classList.contains('hidden') && !modalBackdrop.classList.contains('hidden')) {
      modalBackdrop.classList.add('hidden');
      modalBackdrop.setAttribute('aria-hidden', 'true');
    }
  }

  if (modalBackdrop) modalBackdrop.classList.add('hidden');
  if (modal) modal.className = 'modal hidden';
  if (modalActions) modalActions.innerHTML = '';
  if (modalMessage) modalMessage.textContent = '';
  clearStaleModalBackdrop();

  // Pagination & Search State
  let allPosts = [];
  let allPages = [];
  let allArchive = [];
  let pageSize = 10;
  let postsPage = 1;
  let pagesPage = 1;
  let archivePage = 1;
  let searchQuery = '';
  let dateFrom = null;
  let dateTo = null;
  let dateFromStartTs = null;
  let dateToEndTs = null;
  let isLoading = false;

  // Debounce helper
  function debounce(fn, delay = 300) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), delay);
    };
  }

  // Set loading state on a list
  function setListLoading(listEl, loading) {
    listEl.setAttribute('aria-busy', loading ? 'true' : 'false');
    if (loading) {
      listEl.innerHTML = `<li class="loading-state">
        <span class="loading-spinner" aria-hidden="true"></span>
        <span>${t('dashboard.loading')}</span>
      </li>`;
    }
  }

  // Show error in the error alert area
  function showError(message) {
    if (errorAlert) {
      errorAlert.textContent = message;
      errorAlert.classList.remove('hidden');
      // Auto-hide after 5 seconds
      setTimeout(() => {
        errorAlert.classList.add('hidden');
      }, 5000);
    }
  }

  // Hide error alert
  function hideError() {
    if (errorAlert) {
      errorAlert.classList.add('hidden');
    }
  }

  // Check setup first
  let status;
  try {
    status = await App.getSetupStatus();
  } catch (err) {
    document.getElementById('loading-overlay')?.remove();
    dashboardView.classList.remove('hidden');
    showError(t('errors.network'));
    return;
  }

  if (!status.setupComplete) {
    window.location.href = '/setup/';
    return;
  }

  // Check if auth is required
  try {
    const config = await App.getConfig();

    if (config.authEnabled) {
      const loggedIn = await App.isLoggedIn();
      if (!loggedIn) {
        window.location.href = '/admin/login.html';
        return;
      }
    }
  } catch (err) {
    document.getElementById('loading-overlay')?.remove();
    dashboardView.classList.remove('hidden');
    showError(t('errors.network'));
    return;
  }

  // Hide loading overlay and show dashboard
  document.getElementById('loading-overlay')?.remove();
  dashboardView.classList.remove('hidden');
  loadAllContent();

  // Check for available updates
  checkForUpdates();

  // Date range picker dropdown
  dateRangeDropdown.classList.add('hidden');
  dateRangeTrigger.classList.remove('active');

  dateRangeTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    dateRangeDropdown.classList.toggle('hidden');
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!dateRangeTrigger.contains(e.target) && !dateRangeDropdown.contains(e.target)) {
      dateRangeDropdown.classList.add('hidden');
    }
  });

  // Update date range label
  function updateDateRangeLabel() {
    const locale = i18n.getFullLocale();
    if (dateFrom && dateTo) {
      const fromFormatted = new Date(dateFrom).toLocaleDateString(locale, { day: '2-digit', month: '2-digit', year: 'numeric' });
      const toFormatted = new Date(dateTo).toLocaleDateString(locale, { day: '2-digit', month: '2-digit', year: 'numeric' });
      dateRangeLabel.textContent = t('dashboard.dateRangeBetween', { from: fromFormatted, to: toFormatted });
      dateRangeTrigger.classList.add('active');
    } else if (dateFrom) {
      const fromFormatted = new Date(dateFrom).toLocaleDateString(locale, { day: '2-digit', month: '2-digit', year: 'numeric' });
      dateRangeLabel.textContent = t('dashboard.dateRangeFrom', { date: fromFormatted });
      dateRangeTrigger.classList.add('active');
    } else if (dateTo) {
      const toFormatted = new Date(dateTo).toLocaleDateString(locale, { day: '2-digit', month: '2-digit', year: 'numeric' });
      dateRangeLabel.textContent = t('dashboard.dateRangeTo', { date: toFormatted });
      dateRangeTrigger.classList.add('active');
    } else {
      dateRangeLabel.textContent = t('dashboard.date');
      dateRangeTrigger.classList.remove('active');
    }
  }

  function updateDateBounds() {
    dateFromStartTs = null;
    dateToEndTs = null;

    if (dateFrom) {
      const fromDate = new Date(dateFrom);
      fromDate.setHours(0, 0, 0, 0);
      const fromTs = fromDate.getTime();
      if (!Number.isNaN(fromTs)) {
        dateFromStartTs = fromTs;
      }
    }

    if (dateTo) {
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999);
      const toTs = toDate.getTime();
      if (!Number.isNaN(toTs)) {
        dateToEndTs = toTs;
      }
    }
  }

  // Clear dates button
  clearDatesBtn.addEventListener('click', () => {
    dateFromInput.value = '';
    dateToInput.value = '';
    dateFrom = null;
    dateTo = null;
    updateDateBounds();
    postsPage = 1;
    pagesPage = 1;
    archivePage = 1;
    updateDateRangeLabel();
    renderCurrentView();
  });

  // Page size change handler
  pageSizeSelect.addEventListener('change', () => {
    pageSize = pageSizeSelect.value === 'all' ? Infinity : parseInt(pageSizeSelect.value, 10);
    postsPage = 1;
    pagesPage = 1;
    renderCurrentView();
  });

  // Search handler with debounce
  searchInput.addEventListener('input', debounce(() => {
    searchQuery = searchInput.value.trim().toLowerCase();
    postsPage = 1;
    pagesPage = 1;
    archivePage = 1;
    renderCurrentView();
  }, 200));

  // Date range handlers
  dateFromInput.addEventListener('change', () => {
    dateFrom = dateFromInput.value;
    updateDateBounds();
    postsPage = 1;
    pagesPage = 1;
    archivePage = 1;
    updateDateRangeLabel();
    renderCurrentView();
  });

  dateToInput.addEventListener('change', () => {
    dateTo = dateToInput.value;
    updateDateBounds();
    postsPage = 1;
    pagesPage = 1;
    archivePage = 1;
    updateDateRangeLabel();
    renderCurrentView();
  });

  updateDateRangeLabel();
  updateDateBounds();

  // Logout handler
  logoutBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      await App.logout();
      window.location.href = '/admin/login.html';
    } catch (err) {
      showError(t('errors.generic', { error: err.message }));
    }
  });

  // ============ MODAL SYSTEM ============

  const Modal = (() => {
    const backdrop = document.getElementById('modal-backdrop');
    const modal = document.getElementById('modal');
    const message = document.getElementById('modal-message');
    const actions = document.getElementById('modal-actions');

    function hide() {
      modal.classList.add('hidden');
      backdrop.classList.add('hidden');
      backdrop.setAttribute('aria-hidden', 'true');
      modal.className = 'modal hidden';
      actions.innerHTML = '';
    }

    function show(text, buttons, type = '') {
      message.textContent = text;
      actions.innerHTML = '';
      modal.className = 'modal' + (type ? ` modal-${type}` : '');

      buttons.forEach(btn => {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = btn.text;
        button.className = btn.class || '';
        button.addEventListener('click', () => {
          hide();
          if (btn.action) btn.action();
        });
        actions.appendChild(button);
      });

      backdrop.classList.remove('hidden');
      backdrop.setAttribute('aria-hidden', 'false');
      modal.classList.remove('hidden');

      // Focus first button for accessibility
      const firstBtn = actions.querySelector('button');
      if (firstBtn) firstBtn.focus();
    }

    // Handle escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
        hide();
      }
    });

    return {
      confirm(text) {
        return new Promise(resolve => {
          show(text, [
            { text: t('modal.yes'), class: 'btn-danger', action: () => resolve(true) },
            { text: t('modal.cancel'), class: 'btn-secondary', action: () => resolve(false) }
          ]);
        });
      },

      error(text) {
        show(text, [{ text: t('modal.ok'), class: 'btn-primary' }], 'error');
      },

      hide
    };
  })();

  // ============ TABS ============

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      tabBtns.forEach(b => b.classList.toggle('active', b === btn));
      tabContents.forEach(c => c.classList.toggle('active', c.id === `tab-${tab}`));
      tabContents.forEach(c => c.classList.toggle('hidden', c.id !== `tab-${tab}`));
    });
  });

  async function loadAllContent() {
    isLoading = true;
    hideError();

    // Show loading state on all lists
    setListLoading(postsList, true);
    setListLoading(pagesList, true);
    setListLoading(archiveList, true);

    try {
      const allContent = await App.getPosts();
      const normalizedContent = allContent.map(item => {
        const publishedTs = Date.parse(item.publishedAt || '');
        return {
          ...item,
          _publishedTs: Number.isNaN(publishedTs) ? null : publishedTs,
        };
      });

      // Split into posts, pages, and archive (tombstones), sort by date
      allPosts = normalizedContent
        .filter(item => item.pageType !== 'page' && item.status !== 'tombstone')
        .sort((a, b) => (b._publishedTs || 0) - (a._publishedTs || 0));

      allPages = normalizedContent
        .filter(item => item.pageType === 'page' && item.status !== 'tombstone')
        .sort((a, b) => (b._publishedTs || 0) - (a._publishedTs || 0));

      allArchive = normalizedContent
        .filter(item => item.status === 'tombstone')
        .sort((a, b) => (b._publishedTs || 0) - (a._publishedTs || 0));

      isLoading = false;
      renderCurrentView();
    } catch (err) {
      isLoading = false;
      showError(t('dashboard.loadError'));

      // Show error state in lists
      const errorHtml = `<li class="empty error-state">${t('dashboard.loadError')}</li>`;
      postsList.innerHTML = errorHtml;
      pagesList.innerHTML = errorHtml;
      archiveList.innerHTML = errorHtml;

      // Remove loading state
      postsList.setAttribute('aria-busy', 'false');
      pagesList.setAttribute('aria-busy', 'false');
      archiveList.setAttribute('aria-busy', 'false');

      console.error(err);
    }
  }

  function filterItems(items) {
    return items.filter(item => {
      // Text search filter (title and slug)
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesText = item.title.toLowerCase().includes(query) ||
                            item.slug.toLowerCase().includes(query);
        if (!matchesText) return false;
      }

      // Date range filter
      if (dateFromStartTs !== null || dateToEndTs !== null) {
        const itemTs = item._publishedTs;
        if (!Number.isFinite(itemTs)) return false;

        if (dateFromStartTs !== null && itemTs < dateFromStartTs) return false;
        if (dateToEndTs !== null && itemTs > dateToEndTs) return false;
      }

      return true;
    });
  }

  function renderCurrentView() {
    clearStaleModalBackdrop();

    const filteredPosts = filterItems(allPosts);
    const filteredPages = filterItems(allPages);
    const filteredArchive = filterItems(allArchive);
    renderPaginatedList(postsList, postsPagination, filteredPosts, postsPage, 'Post', t('dashboard.noPosts'), (p) => { postsPage = p; renderCurrentView(); });
    renderPaginatedList(pagesList, pagesPagination, filteredPages, pagesPage, t('tabs.pages'), t('dashboard.noPages'), (p) => { pagesPage = p; renderCurrentView(); });
    renderPaginatedList(archiveList, archivePagination, filteredArchive, archivePage, '', t('dashboard.noArchive'), (p) => { archivePage = p; renderCurrentView(); });
  }

  function renderPaginatedList(listEl, paginationEl, items, currentPage, typeName, emptyText, onPageChange) {
    // Mark as no longer loading
    listEl.setAttribute('aria-busy', 'false');

    if (items.length === 0) {
      // Empty state with call-to-action
      const hasCreateLink = typeName && typeName !== '';
      listEl.innerHTML = `<li class="empty-state">
        <div class="empty-state-icon" aria-hidden="true">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14 2 14 8 20 8"/>
            <line x1="12" y1="18" x2="12" y2="12"/>
            <line x1="9" y1="15" x2="15" y2="15"/>
          </svg>
        </div>
        <p class="empty-state-text">${emptyText}</p>
        ${hasCreateLink ? `<a href="editor.html" class="btn btn-primary empty-state-cta">${t('dashboard.createFirst', { type: typeName })}</a>` : ''}
      </li>`;
      paginationEl.classList.add('hidden');
      return;
    }

    const totalItems = items.length;
    const effectivePageSize = pageSize === Infinity ? totalItems : pageSize;
    const totalPages = Math.ceil(totalItems / effectivePageSize);
    const safeCurrentPage = Math.min(currentPage, totalPages);
    const startIndex = (safeCurrentPage - 1) * effectivePageSize;
    const endIndex = Math.min(startIndex + effectivePageSize, totalItems);
    const pageItems = items.slice(startIndex, endIndex);

    function buildMetaText(item, safeSlugText) {
      const metaParts = [`/${safeSlugText}`];

      const publishedAt = item.publishedAt ? new Date(item.publishedAt) : null;
      const modifiedAt = item.modifiedAt ? new Date(item.modifiedAt) : null;
      const hasPublished = publishedAt && !Number.isNaN(publishedAt.getTime());
      const hasModified = modifiedAt && !Number.isNaN(modifiedAt.getTime());

      if (hasModified && (!hasPublished || modifiedAt.getTime() > publishedAt.getTime())) {
        metaParts.push(t('dashboard.modifiedAt', { date: App.formatDate(item.modifiedAt) }));
      } else if (hasPublished) {
        metaParts.push(t('dashboard.publishedAt', { date: App.formatDate(item.publishedAt) }));
      }

      const author = String(item.author || '').trim();
      if (author) {
        metaParts.push(t('dashboard.byAuthor', { author: App.escapeHtml(author) }));
      }

      if (item.status === 'tombstone') {
        metaParts.push(`<span class="text-muted">${t('dashboard.deleted')}</span>`);
      }

      return metaParts.join(' · ');
    }

    listEl.innerHTML = pageItems.map(item => {
      const rawSlug = String(item.slug || '');
      const safeSlugText = App.escapeHtml(rawSlug);
      const safeSlugAttr = App.escapeHtml(rawSlug);
      const safeSlugPath = encodeURIComponent(rawSlug);
      const safeTitle = App.escapeHtml(item.title);
      const metaText = buildMetaText(item, safeSlugText);

      return `
      <li>
        <div class="post-info">
          <div class="post-title ${item.status === 'tombstone' ? 'status-tombstone' : ''}">
            ${item.status === 'tombstone'
              ? safeTitle
              : `<a href="/${safeSlugPath}" target="_blank" rel="noopener">
                  ${safeTitle}
                  <svg class="post-title-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                    <polyline points="15 3 21 3 21 9" />
                    <line x1="10" y1="14" x2="21" y2="3" />
                  </svg>
                </a>`
            }
          </div>
          <div class="post-meta">
            ${metaText}
          </div>
        </div>
        <div class="post-actions">
          ${item.status === 'published' ? `
            <button type="button" class="btn btn-secondary btn-small btn-icon" data-action="recompile" data-slug="${safeSlugAttr}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 2v6h-6"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M3 22v-6h6"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/></svg>
              ${t('dashboard.recompile')}
            </button>
            <button type="button" class="btn btn-secondary btn-small btn-icon" data-action="duplicate" data-slug="${safeSlugAttr}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              ${t('dashboard.duplicate')}
            </button>
            <span class="action-separator" aria-hidden="true"></span>
            <button type="button" class="btn btn-danger btn-small btn-icon" data-action="delete" data-slug="${safeSlugAttr}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              ${t('dashboard.delete')}
            </button>
          ` : ''}
        </div>
      </li>
    `;
    }).join('');

    // Render pagination
    if (totalPages <= 1) {
      paginationEl.classList.add('hidden');
      return;
    }

    paginationEl.classList.remove('hidden');
    paginationEl.innerHTML = '';

    // Previous button
    const prevBtn = document.createElement('button');
    prevBtn.type = 'button';
    prevBtn.textContent = '‹';
    prevBtn.setAttribute('aria-label', 'Previous page');
    prevBtn.disabled = safeCurrentPage === 1;
    prevBtn.addEventListener('click', () => onPageChange(safeCurrentPage - 1));
    paginationEl.appendChild(prevBtn);

    // Page numbers
    const maxButtons = 5;
    let startPage = Math.max(1, safeCurrentPage - Math.floor(maxButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxButtons - 1);
    if (endPage - startPage < maxButtons - 1) {
      startPage = Math.max(1, endPage - maxButtons + 1);
    }

    if (startPage > 1) {
      const firstBtn = document.createElement('button');
      firstBtn.type = 'button';
      firstBtn.textContent = '1';
      firstBtn.addEventListener('click', () => onPageChange(1));
      paginationEl.appendChild(firstBtn);
      if (startPage > 2) {
        const dots = document.createElement('span');
        dots.className = 'pagination-info';
        dots.textContent = '…';
        dots.setAttribute('aria-hidden', 'true');
        paginationEl.appendChild(dots);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = i;
      btn.className = i === safeCurrentPage ? 'active' : '';
      if (i === safeCurrentPage) {
        btn.setAttribute('aria-current', 'page');
      }
      btn.addEventListener('click', () => onPageChange(i));
      paginationEl.appendChild(btn);
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        const dots = document.createElement('span');
        dots.className = 'pagination-info';
        dots.textContent = '…';
        dots.setAttribute('aria-hidden', 'true');
        paginationEl.appendChild(dots);
      }
      const lastBtn = document.createElement('button');
      lastBtn.type = 'button';
      lastBtn.textContent = totalPages;
      lastBtn.addEventListener('click', () => onPageChange(totalPages));
      paginationEl.appendChild(lastBtn);
    }

    // Next button
    const nextBtn = document.createElement('button');
    nextBtn.type = 'button';
    nextBtn.textContent = '›';
    nextBtn.setAttribute('aria-label', 'Next page');
    nextBtn.disabled = safeCurrentPage === totalPages;
    nextBtn.addEventListener('click', () => onPageChange(safeCurrentPage + 1));
    paginationEl.appendChild(nextBtn);
  }

  // Event delegation for post actions
  document.addEventListener('click', async (e) => {
    const target = e.target.closest('[data-action]');
    if (!target) return;

    const action = target.dataset.action;
    const slug = target.dataset.slug;

    switch (action) {
      case 'delete': {
        const confirmed = await Modal.confirm(t('dashboard.deleteConfirm', { slug }));
        if (!confirmed) return;

        try {
          await App.deletePost(slug);
          loadAllContent();
        } catch (err) {
          Modal.error(t('dashboard.deleteError', { error: err.message }));
        }
        break;
      }

      case 'recompile': {
        window.location.href = `editor.html?edit=${encodeURIComponent(slug)}`;
        break;
      }

      case 'duplicate': {
        try {
          const { sourceData } = await App.clonePage(slug, 'page');
          sessionStorage.setItem('clonedSource', JSON.stringify(sourceData));
          window.location.href = 'editor.html?clone=true';
        } catch (err) {
          Modal.error(t('dashboard.duplicateError', { error: err.message }));
        }
        break;
      }
    }
  });
}

// Check for available updates from GitHub
export async function checkForUpdates() {
  try {
    const response = await fetch('/api/check-updates');
    if (!response.ok) return;
    
    const data = await response.json();
    
    if (data.updateAvailable) {
      showUpdateBanner(data);
    }
  } catch (err) {
    // Silently fail - update check is not critical
    console.log('Update check failed:', err.message);
  }
}

// Check if update should be shown based on user preferences
export function shouldShowUpdate(version) {
  // Check if permanently dismissed
  const dismissedVersion = localStorage.getItem('dismissedUpdateVersion');
  if (dismissedVersion === version) {
    return false;
  }
  
  // Check if snoozed
  const snoozeData = localStorage.getItem('snoozedUpdate');
  if (snoozeData) {
    try {
      const { version: snoozedVersion, until } = JSON.parse(snoozeData);
      if (snoozedVersion === version && Date.now() < until) {
        return false;
      }
    } catch (e) {
      // Invalid data, clear it
      localStorage.removeItem('snoozedUpdate');
    }
  }
  
  return true;
}

// Show update notification banner
export function showUpdateBanner(updateInfo) {
  // Check if should show based on user preferences
  if (!shouldShowUpdate(updateInfo.latest)) {
    return;
  }

  function toSafeExternalUrl(url) {
    try {
      const parsed = new URL(url, window.location.origin);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return parsed.href;
      }
    } catch {
      // invalid URL
    }
    return '#';
  }

  function createButtonIcon(pathData) {
    const svgNs = 'http://www.w3.org/2000/svg';
    const icon = document.createElementNS(svgNs, 'svg');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('width', '14');
    icon.setAttribute('height', '14');
    icon.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS(svgNs, 'path');
    path.setAttribute('d', pathData);
    path.setAttribute('fill', 'currentColor');
    icon.appendChild(path);
    return icon;
  }

  function createRecompileIcon() {
    const svgNs = 'http://www.w3.org/2000/svg';
    const icon = document.createElementNS(svgNs, 'svg');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('width', '14');
    icon.setAttribute('height', '14');
    icon.setAttribute('fill', 'none');
    icon.setAttribute('stroke', 'currentColor');
    icon.setAttribute('stroke-width', '2');
    icon.setAttribute('aria-hidden', 'true');

    const polylineTop = document.createElementNS(svgNs, 'polyline');
    polylineTop.setAttribute('points', '23 4 23 10 17 10');

    const polylineBottom = document.createElementNS(svgNs, 'polyline');
    polylineBottom.setAttribute('points', '1 20 1 14 7 14');

    const path = document.createElementNS(svgNs, 'path');
    path.setAttribute('d', 'M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15');

    icon.append(polylineTop, polylineBottom, path);
    return icon;
  }
  
  const dashboardView = document.getElementById('dashboard-view');
  const banner = document.createElement('div');
  banner.className = 'update-banner';
  banner.setAttribute('role', 'alert');
  const latestVersion = String(updateInfo.latest || '');
  const currentVersion = String(updateInfo.current || '');
  const safeReleaseUrl = toSafeExternalUrl(updateInfo.releaseUrl);

  const content = document.createElement('div');
  content.className = 'update-banner-content';

  const textWrap = document.createElement('div');
  textWrap.className = 'update-banner-text';
  const title = document.createElement('strong');
  title.textContent = t('dashboard.updateAvailable', { version: latestVersion });
  const current = document.createElement('span');
  current.textContent = t('dashboard.currentVersion', { version: currentVersion });
  textWrap.append(title, current);

  const actions = document.createElement('div');
  actions.className = 'update-banner-actions';

  const releaseLink = document.createElement('a');
  releaseLink.className = 'btn btn-small btn-primary';
  releaseLink.href = safeReleaseUrl;
  releaseLink.target = '_blank';
  releaseLink.rel = 'noopener noreferrer';
  releaseLink.append(
    createButtonIcon('M14 3h7v7h-2V6.414l-9.293 9.293-1.414-1.414L17.586 5H14V3zM5 5h7v2H7v10h10v-5h2v7H5V5z'),
    document.createTextNode(t('dashboard.viewRelease'))
  );

  const snoozeBtn = document.createElement('button');
  snoozeBtn.type = 'button';
  snoozeBtn.className = 'btn btn-small btn-text snooze-update';
  snoozeBtn.dataset.version = latestVersion;
  snoozeBtn.append(
    createRecompileIcon(),
    document.createTextNode(t('dashboard.remindLater'))
  );

  const dismissBtn = document.createElement('button');
  dismissBtn.type = 'button';
  dismissBtn.className = 'btn btn-small btn-text dismiss-update';
  dismissBtn.dataset.version = latestVersion;
  dismissBtn.append(
    createButtonIcon('M18.3 5.71 12 12l6.3 6.29-1.41 1.42L10.59 13.4 4.29 19.71 2.88 18.3 9.17 12 2.88 5.71 4.29 4.29l6.3 6.3 6.29-6.3z'),
    document.createTextNode(t('modal.dismiss'))
  );

  actions.append(releaseLink, snoozeBtn, dismissBtn);
  content.append(textWrap, actions);
  banner.appendChild(content);
  
  // Insert at the top of dashboard
  dashboardView.insertBefore(banner, dashboardView.firstChild);
  
  // Snooze handler (7 days)
  banner.querySelector('.snooze-update').addEventListener('click', (e) => {
    const version = e.currentTarget.dataset.version;
    const snoozeUntil = Date.now() + (7 * 24 * 60 * 60 * 1000); // 7 days
    localStorage.setItem('snoozedUpdate', JSON.stringify({
      version: version,
      until: snoozeUntil
    }));
    banner.remove();
  });
  
  // Dismiss handler (permanent for this version)
  banner.querySelector('.dismiss-update').addEventListener('click', (e) => {
    const version = e.currentTarget.dataset.version;
    localStorage.setItem('dismissedUpdateVersion', version);
    localStorage.removeItem('snoozedUpdate'); // Clear any snooze
    banner.remove();
  });
}

// Auto-initialize when DOM is ready (dashboard page only)
export function autoInitDashboard() {
  if (!document.getElementById('dashboard-view')) return;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}

autoInitDashboard();
